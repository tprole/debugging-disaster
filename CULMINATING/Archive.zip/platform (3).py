#!/usr/bin/env python
# coding: utf-8

# In[1]:


# from email.mime import image
import turtle
import random
import glob
import time


# In[2]:


win = turtle.Screen()
win.setup(1195, 835)
filenames = glob.glob('./graphics/gif images/*.gif')
print(filenames)
keys = ['tara', 'sword', 'coin', 'sword-engaged', 'sword-neutral', 'cardinale-R', 'cardinale-4+', 'cardinale', 'backdrop', 'flip-sword-engaged', 'flip', 'flip-sword-neutral']
imageFiles = dict(zip(keys, filenames))
for file in imageFiles:
    win.register_shape(imageFiles[file])
win.bgpic(imageFiles['backdrop'])
win.listen()
turtle.delay(0)


# In[3]:


platforms = {
    'right_wall': 540,
    'left_wall': -500,
    'top_wall': 310,
    'first_left_x': 375,
    'first_right_x' : 540,
    'first_top_y' : -85,
    'second_left_x': -420,
    'second_right_x': 266,
    'second_top_y': -20,
    'third_right_x': 85,
    'third_left_x': -120,
    'third_top_y': 70,
    'fourth_top_y': 130,
    'fourth_left_x': 189,
    'fourth_right_x': 406,
    'fifth_top_y': 155,
    'fifth_right_x': -200,
    'fifth_left_x': -439,
    'sixth_left_x': -185,
    'sixth_right_x': 75,
    'sixth_top_y': 255,
    'seventh_left_x': 100,
    'seventh_right_x': 540,
    'seventh_top_y': 300
}


# In[4]:


# me = turtle.Turtle()
# me.hideturtle()
# me.shape(imageFiles['tara'])
# me.penup()
# me.setposition(-450, -200)
# me.showturtle()


# In[ ]:







# In[6]:
mainX = -450
mainY = -200
jumpCount = 0

class Me(turtle.Turtle):
    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.direction = "right"
        self.onPlatform = True
        self.shape(imageFiles['tara'])
        self.penup()
        self.swordEquipped = False
        self.jump = False
        self.speed = 1
        self.setposition(-450, -200)
        self.showturtle() 

    def is_on_platform(self):
        global mainY, mainX

        if mainY >= platforms['first_top_y']-5 and mainY <= platforms['first_top_y']+3 and mainX >= platforms['first_left_x'] and mainX <= platforms['first_right_x']: # First platform
            self.onPlatform = True
        elif mainY >= platforms['second_top_y']-5 and mainY <= platforms['second_top_y']+3 and mainX <= platforms['second_right_x'] and mainX >= platforms['second_left_x']: # Second platform
            self.onPlatform = True
        elif mainY >= platforms['third_top_y']-5 and mainY <= platforms['third_top_y']+3 and mainX <= platforms['third_right_x'] and mainX >= platforms['third_left_x']: # Third platform
            self.onPlatform = True
        elif mainY >= platforms['fourth_top_y']-5 and mainY <= platforms['fourth_top_y']+3 and mainX <= platforms['fourth_right_x'] and mainX >= platforms['fourth_left_x']: # Fourth platform
            self.onPlatform = True
        elif mainY >= platforms['fifth_top_y']-5 and mainY <= platforms['fifth_top_y']+3 and mainX <= platforms['fifth_right_x'] and mainX >= platforms['fifth_left_x']: # Fifth platform
            self.onPlatform = True
        elif mainY >= platforms['sixth_top_y']-5 and mainY <= platforms['sixth_top_y']+3 and mainX <= platforms['sixth_right_x'] and mainX >= platforms['sixth_left_x']: # Sixth platform
            self.onPlatform = True
        elif mainY >= platforms['seventh_top_y']-5 and mainY <= platforms['seventh_top_y']+3 and mainX <= platforms['seventh_right_x'] and mainX >= platforms['seventh_left_x']: # Sixth platform
            self.onPlatform = True
        elif mainY <= -210: # Bottom of screen
            self.onPlatform = True
        else:
            self.onPlatform = False

    def equipSword(self, sword):
        if sword.collected == True:
            if self.direction == 'right':
                self.shape(imageFiles['sword-neutral'])
            elif self.direction == 'left':
                self.shape(imageFiles['flip-sword-neutral'])
            self.swordEquipped = True
            self.swordEngaged = False

    def gravity(self):
        global mainY
        self.is_on_platform()
        if self.onPlatform != True:
            mainY = mainY - 5

    def dead(self, cardinale1, cardinale2):
        global mainX, mainY, slash, gameOn
        if cardinale1.dying != True:
            if mainX <= cardinale1.x + 50 and mainX >= cardinale1.x - 50 and slash != True:
                if mainY <= cardinale1.y + 25 and mainY >= cardinale1.y - 25:
                    gameOn = False
        if cardinale2.dying != True:                     
            if mainX <= cardinale2.x + 50 and mainX >= cardinale2.x - 50 and slash != True:
                if mainY <= cardinale2.y + 25 and mainY >= cardinale2.y - 25:
                    gameOn = False

                

    def walls(self):
        global mainX
        global mainY
        if mainX > platforms['right_wall']:
            mainX = mainX - 10
            self.direction = "left"
            if self.swordEquipped:
                self.shape(imageFiles['flip-sword-neutral'])
            else:
                self.shape(imageFiles['flip'])
        elif mainX < platforms['left_wall']:
            mainX = mainX + 10
            self.direction = "right"
            if self.swordEquipped:
                self.shape(imageFiles['sword-neutral'])
            else:
                self.shape(imageFiles['tara'])
        elif mainY >= platforms['top_wall']:
            mainY = mainY - 10
        # if mainX < platforms['left_wall']:
        #     mainX = mainX + 10

# # In[ ]:

class Sword(turtle.Turtle):

    def __init__(self, character):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.shape(imageFiles['sword'])
        self.setposition(200, -200)
        self.showturtle()
        self.x = 200
        self.y = -200
        self.character = character
        self.collected = False
    def checkCollected(self):
        global mainX
        if self.x > mainX - 30 and self.x < mainX + 30:
            self.hideturtle()
            self.collected = True



class Cardinale(turtle.Turtle):

    def __init__(self, character, x, y, platform_left, platform_right, platform_y):
        super().__init__()
        self.speed(1)
        self.penup()
        self.shape(imageFiles['cardinale-R'])
        self.direction = 'left'
        self.x = x
        self.y = y
        self.platform_left = platform_left
        self.platform_right = platform_right
        self.platform_y = platform_y
        self.setposition(self.x, self.y)
        self.character = character
        self.defeated = False
        self.speed = 2
        self.deathCount = 0
        self.dying = False

    def defeat(self):
        if self.defeated == True:
            self.dying = True
            self.shape(imageFiles['cardinale-4+'])

    def moveRight(self):
        self.x = self.x + self.speed

    def moveLeft(self):
        self.x = self.x - self.speed
    
    def prowl(self):
        if self.direction == 'left':
            self.moveLeft()
        elif self.direction == 'right':
            self.moveRight()
        if self.x >= self.platform_right:
            self.direction = 'left'
        elif self.x <= self.platform_left:
            self.direction = 'right'
        if self.deathCount == 50:
            self.hideturtle()
            self.x = -600
            self.y = 600

    def detectSword(self):
        if self.character.engageSword() ==True: #chagned
            self.shape(imageFiles['cardinale-4+'])
            #time.

#
# # In[7]:
#

gameOn = True
mainChar = Me()
sword = Sword(mainChar)
cardinale1 = Cardinale(mainChar, 100, 70, -120, 85, 70)
cardinale2 = Cardinale(mainChar, -300, 155, -439, -200, 155)
# global mainX, mainY

slash = False
slashCount = 0

def slash():
    global slash
    if mainChar.swordEquipped:
        slash = True
        

def engageSword():
    global slash, slashCount, mainX, mainY
    if mainChar.swordEquipped == True and slash == True:
        if slash:
            if slashCount == 1:
                if mainChar.direction == 'right':
                    mainChar.shape(imageFiles['sword-engaged'])
                else:
                    mainChar.shape(imageFiles['flip-sword-engaged'])
            mainChar.swordEngaged = True
            if mainX <= cardinale1.xcor() + 100 and mainX >= cardinale1.xcor() - 100:
                if mainY <= cardinale1.ycor() + 100 and mainY >= cardinale1.ycor() - 100:
                    cardinale1.defeated = True
            if mainX <= cardinale2.xcor() + 100 and mainX >= cardinale2.xcor() - 100:
                if mainY <= cardinale2.ycor() + 100 and mainY >= cardinale2.ycor() - 100:
                    cardinale2.defeated = True
            slashCount + slashCount + 1
            
        if slashCount >= 30:
            slashCount = 0
            slash = False
            if mainChar.direction == 'right':
                mainChar.shape(imageFiles['sword-neutral'])
            else:
                mainChar.shape(imageFiles['flip-sword-neutral'])

def moveRight():
    global mainX

    mainX = mainX + mainChar.speed
    
    #self.goto(mainChar.xcor() + 10, mainChar.ycor())

def moveLeft():
    global mainX
    mainX = mainX - mainChar.speed

    #self.goto(mainChar.xcor() - 10, mainChar.ycor())

def jump():
    global mainY
    global mainX
    global jumpCount
    if not mainY >= platforms['top_wall'] and mainChar.jump == True:

        mainY = mainY + 15
        mainChar.speed = 15
    elif mainY >= platforms['top_wall']:
        jumpCount = 10
    if jumpCount >= 10:
        mainChar.jump = False
        jumpCount = 0
        mainChar.speed = 1
    

def documentcoords():
    print("X-coordinate: {} Y-coordinate: {}".format(mainChar.xcor(), mainChar.ycor()))

def moveChar():
    global jumpCount, slashCount
    if mainChar.direction == "left":
        moveLeft()
    elif mainChar.direction == "right":
        moveRight()
    else:
        pass
    if mainChar.jump == True:
        jump()
        jumpCount = jumpCount + 1
    if slash == True:
        engageSword()
        slashCount = slashCount + 1

def triggerJump():
    if mainChar.onPlatform == True:
        mainChar.jump = True

def turnLeft():
    mainChar.direction = "left"
    if mainChar.swordEquipped == True:
        mainChar.shape(imageFiles['flip-sword-neutral'])
    else:
        mainChar.shape(imageFiles['flip'])

def turnRight():
    mainChar.direction = "right"
    if mainChar.swordEquipped == True:
        mainChar.shape(imageFiles['sword-neutral'])
    else:
        mainChar.shape(imageFiles['tara'])

def stop():
    mainChar.direction = "stop"

turtle.listen()
turtle.onkey(turnLeft, "Left")
turtle.onkey(turnRight, "Right")
turtle.onkey(stop, "Down")
turtle.onkey(triggerJump, "space")
turtle.onkey(documentcoords, "y")
turtle.onkey(slash, "k")



while gameOn:
    mainChar.dead(cardinale1, cardinale2)
    moveChar()
    mainChar.goto(mainX,mainY)
    cardinale1.prowl()
    cardinale2.prowl()
    cardinale1.goto(cardinale1.x, cardinale1.y)
    cardinale2.goto(cardinale2.x, cardinale2.y)
    mainChar.is_on_platform()
    if mainChar.jump != True:
        mainChar.gravity()
    mainChar.walls()
    if mainChar.swordEquipped != True:
        sword.checkCollected()
        mainChar.equipSword(sword)
    else: 
        engageSword()
        cardinale1.defeat()
        cardinale2.defeat()
    if cardinale1.dying == True:
        cardinale1.deathCount = cardinale1.deathCount + 1
    if cardinale2.dying == True:
        cardinale2.deathCount = cardinale2.deathCount + 1

win.mainloop()